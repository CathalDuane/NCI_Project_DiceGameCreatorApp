package com.app.RollToo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RollTooApplicationTests {

	@Test
	void contextLoads() {
	}

}
